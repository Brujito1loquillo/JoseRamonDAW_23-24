package joc;

public enum Color {
	BLANC, NEGRE
}
