package peces;

public interface Ordenable {
	public int compareTo(Ordenable e);
}
