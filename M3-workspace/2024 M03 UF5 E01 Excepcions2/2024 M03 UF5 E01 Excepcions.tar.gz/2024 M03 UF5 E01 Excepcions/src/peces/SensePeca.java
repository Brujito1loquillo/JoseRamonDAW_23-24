package peces;

import joc.Color;

public class SensePeca extends Escac {
	
	public SensePeca(Color c) {
		super(c);
	}

	@Override
	public String toString() {
		return super.toString() + "  ";
	}
	
	
}
